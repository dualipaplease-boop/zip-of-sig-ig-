# SentryAgent — Evaluation Artifacts & Test Results Catalog

**Problem Statement:** ISRO — On-device Visual Perception for Light-weight Browser Agents (SIH26171)  
**Location:** `c:\Users\iqand\Downloads\SIH\result`  
**Generated:** 22 September 2026  

---

## 1. Video Demonstration Recordings

| Artifact File | Description & Verification Proof | Size |
|---|---|---|
| [`testbed_all_portals_1790101222348.webp`](file:///c:/Users/iqand/Downloads/SIH/result/testbed_all_portals_1790101222348.webp) | **Complete Multi-Portal Autonomous Verification**: Full session video demonstrating browser interaction across all 3 portals: switching between e-Procurement, HR Deputation, and ISTRAC Mission Operations, loading realistic PII scenarios, and rendering live visual canvases. | 3.45 MB |
| [`istrac_portal_demo_1790100773503.webp`](file:///c:/Users/iqand/Downloads/SIH/result/istrac_portal_demo_1790100773503.webp) | **ISTRAC Mission Operations Deep Dive**: High-definition walkthrough demonstrating the multispectral satellite telemetry canvas, flight director biometric badge, and classified orbital burn authorization gating. | 3.48 MB |
| [`testbed_portal_verification_1790093994710.webp`](file:///c:/Users/iqand/Downloads/SIH/result/testbed_portal_verification_1790093994710.webp) | **Initial Dual-Portal Proving Ground**: Initial baseline test showing e-Procurement and HR Deputation portals. | 3.36 MB |

---

## 2. High-Resolution Visual Evidence (Screenshots)

### A. All Three Live Portals (Final Build)
| Screenshot File | Description | Size |
|---|---|---|
| [`eprocurement_portal_1790101368665.png`](file:///c:/Users/iqand/Downloads/SIH/result/eprocurement_portal_1790101368665.png) | **Portal 1 (e-Procurement)**: Full-page view showing Dr. Arvind S. Swaminathan's tender bid, PAN, GSTIN, escrow account, and vector signature canvas. | 345.8 KB |
| [`hr_deputation_portal_1790101472779.png`](file:///c:/Users/iqand/Downloads/SIH/result/hr_deputation_portal_1790101472779.png) | **Portal 2 (HR & Deputation)**: Full-page view showing Sunita R. Namboodiri's clearance file, Verhoeff-validated Aadhaar (`9999 9999 0019`), and biometric badge avatar. | 320.3 KB |
| [`istrac_mission_ops_all_1790101573967.png`](file:///c:/Users/iqand/Downloads/SIH/result/istrac_mission_ops_all_1790101573967.png) | **Portal 3 (ISTRAC Mission Operations)**: Full-page view showing Cartosat-3 satellite observation canvas, Flight Director biometric avatar, Luhn transponder key, and Tier 4 orbital burn button. | 517.5 KB |
| [`istrac_mission_ops_1790101126252.png`](file:///c:/Users/iqand/Downloads/SIH/result/istrac_mission_ops_1790101126252.png) | **Portal 3 (Telemetry Close-up)**: Detailed render of the multispectral satellite observation grid and telemetry parameters. | 518.1 KB |

### B. Detailed Visual Targets & Canvases
| Screenshot File | Description | Size |
|---|---|---|
| [`eprocurement_bottom_signature_1790094151973.png`](file:///c:/Users/iqand/Downloads/SIH/result/eprocurement_bottom_signature_1790094151973.png) | Detailed view of the HTML5 digital signature pad canvas with realistic bezier vector strokes. | 184.8 KB |
| [`eprocurement_populated_scenario_1790094260858.png`](file:///c:/Users/iqand/Downloads/SIH/result/eprocurement_populated_scenario_1790094260858.png) | Populated e-Procurement form fields with realistic PII test vectors ready for Inversion Vault tokenization. | 189.1 KB |
| [`hr_portal_bottom_avatar_1790094368347.png`](file:///c:/Users/iqand/Downloads/SIH/result/hr_portal_bottom_avatar_1790094368347.png) | Detailed view of the procedural biometric face mask canvas for BlazeFace ONNX detection. | 197.3 KB |
| [`hr_portal_view_1790094330079.png`](file:///c:/Users/iqand/Downloads/SIH/result/hr_portal_view_1790094330079.png) | Default view of the HR Deputation form before scenario loading. | 250.3 KB |
| [`eprocurement_default_view_1790094084844.png`](file:///c:/Users/iqand/Downloads/SIH/result/eprocurement_default_view_1790094084844.png) | Default initial view of the e-Procurement portal. | 246.2 KB |

---

## 3. Technical Deliverables & Specifications
- [`walkthrough.md`](file:///c:/Users/iqand/Downloads/SIH/result/walkthrough.md): Comprehensive system walkthrough detailing all 5 phases, architecture diagrams, and verification benchmarks.
- [`implementation_plan.md`](file:///c:/Users/iqand/Downloads/SIH/result/implementation_plan.md): Architectural design document defining the trust boundaries, model formats, and testing targets.
